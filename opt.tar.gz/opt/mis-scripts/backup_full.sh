#!/bin/bash

if [[ "$1" == "-h" ]] || [[ "$#" -ne 2 ]]; then
	echo "Uso: $0 <directorio_origen> <directorio_destino>"
	exit 1
fi

ORIGEN=$1
DESTINO=$2
echo "Origen: $ORIGEN"
echo "Destino: $DESTINO"
if [[ ! -d "$ORIGEN" ]]; then
	echo "Error: El directorio de origen $ORIGEN no esiste."
	exit 3
fi

if [[ ! -d "$DESTINO" ]];then
	echo "Error: El directorio de destino $DESTINO no existe."
fi

FECHA=$(date +"%Y%m%d")
NOMBRE_BKP=$(basename "$ORIGEN")_bkp_$FECHA.tar.gz

tar -czf "$DESTINO/$NOMBRE_BKP" -C "$ORIGEN" .
if [[ $? -eq 0 ]]; then
	echo "Backup de $ORIGEN realizado con exito en $DESTINO/$NOMBRE_BKP"
else
	echo "Error al hacer el backup"
	exit 4
fi
